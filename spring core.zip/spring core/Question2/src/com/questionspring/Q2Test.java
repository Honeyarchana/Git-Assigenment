package com.questionspring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Q2Test {

	
	public static void main(String args[]) {
		
		ApplicationContext context =new ClassPathXmlApplicationContext("bean.xml");
		Question question1 = (Question) context.getBean("question0");
		System.out.println(question1);
	}
}
