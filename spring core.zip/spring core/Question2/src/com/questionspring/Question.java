package com.questionspring;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Question {

	private int questionId;
    private String question;
    private List<String> answer;
    
  //private Set<String> answer;
    //private Map<Integer,String> answer;

    //Constructor for maps case
    //public Question(int questionId, String question, Map<Integer, String> answer) {
    //    this.questionId = questionId;
    //     this.question = question;
    //    this.answer = answer;
    //}

    //Constructor For sets case
    //public Question(int questionId, String question, Set<String> answer) {
    //    this.questionId = questionId;
    //    this.question = question;
    //    this.answer = answer;
    //}

    //Constructor For Lists case
    public Question(int questionId, String question, List<String> answer) 
    {
        this.questionId = questionId;
        this.question = question;
        this.answer = answer;
     }

    public int getQuestionId() {
        return questionId;
    }
    public String getQuestion() {
        return question;
    }

    //public Map<Integer, String> getAnswer() {
    //    return answer;
    //}
    //getter for sets case
    //public Set<String> getAnswers() {
    //    return answer;
    //}

    //getter for lists case
    public List<String> getAnswers() {
        return answer;
    }
    
    @Override
    public String toString() {
        return "Question{" +
                "questionId=" + questionId +
                ", question='" + question + '\'' +
                ", answer=" + answer +
                '}';
    }


    
}
    
	
	
	

