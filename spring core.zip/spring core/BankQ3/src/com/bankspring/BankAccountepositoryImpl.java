package com.bankspring;

public class BankAccountepositoryImpl implements BankAccountRepository {

	@Override
	public double getBalance(long accountId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double updateBalance(long accountID, double newBalance) {
		// TODO Auto-generated method stub
		return 0;
	}

}
