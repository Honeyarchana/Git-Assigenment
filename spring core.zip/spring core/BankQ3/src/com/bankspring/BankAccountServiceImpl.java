package com.bankspring;

public class BankAccountServiceImpl implements BankAccountService {

	@Override
	public double withdraw(long accountId, double balance) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double deposit(long accountId, double balance) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getBalance(long accountId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean fundTransfer(long fromAccount, long toAccount, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

}
