package com.bankspring;

public class BankAccountController {
	
   
    public void Controller()
    {
         
    	System.out.println("this bankaccount controller");
    	System.out.println("above data entry is successfull");
       
    }
    
    
    
    
    
    
    
    
    
    
    
    public double withdraw(long accountId, double balance){
        return 0;
        }
        public double deposit(long accountId, double balance){
            return 0;
        }
        public double getBalance(long accountId){
            return 0;
        }
        public boolean fundTransfer(long fromAccount, long toAccount){
            return false;
        }
    }

