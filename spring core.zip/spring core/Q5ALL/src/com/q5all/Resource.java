package com.q5all;

public @interface Resource {
	
}
