package com.q5all;

public class School {
	 private  String name;
	    private int TotalStudent;

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public int getTotalStudent() {
	        return TotalStudent;
	    }

	    public void setTotalStudent(int totalStudent) {
	        TotalStudent = totalStudent;
	    }

}
