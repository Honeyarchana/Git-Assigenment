package com.q8all;

public @interface PostConstruct {

}
