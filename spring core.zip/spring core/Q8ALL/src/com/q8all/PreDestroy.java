package com.q8all;

public @interface PreDestroy {

}
